package matc89.rest;

import android.support.annotation.NonNull;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rodrigorgs on 20/09/19.
 */

public class ContatoResource {
    private static final String BASE_URL = "http://contatos-rest.herokuapp.com/contatos";



    public List<Contato> getContatos() throws IOException {
        URL url = new URL(BASE_URL);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("GET");
        Log.i("zzz", "Response Code: " + conn.getResponseCode());

        BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String corpo = "";
        String linha = br.readLine();
        while (linha != null) {
            corpo += linha + "\n";
            linha = br.readLine();
        }

        ArrayList<Contato> contatos = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(corpo);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                Contato contato = jsonObjectToContato(jsonObject);
                contatos.add(0, contato);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.i("zzz", "Corpo: " + corpo);

        return contatos;
    }

    @NonNull
    private Contato jsonObjectToContato(JSONObject jsonObject) throws JSONException {
        int id = jsonObject.getInt("id");
        String nome = jsonObject.getString("nome");
        String telefone = jsonObject.getString("telefone");

        return new Contato(id, nome, telefone);
    }

    public Long insertContato(Contato contato) throws IOException {
        URL url = new URL(BASE_URL);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("POST");

        OutputStream os = conn.getOutputStream();
        PrintStream ps = new PrintStream(os);

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("nome", contato.getNome());
            jsonObject.put("telefone", contato.getTelefone());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.i("zzz", "JSON enviado: " + jsonObject.toString());
        ps.print(jsonObject.toString());

        Log.i("zzz", "Response Code: " + conn.getResponseCode());

        BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String corpo = "";
        String linha = br.readLine();
        while (linha != null) {
            corpo += linha + "\n";
            linha = br.readLine();
        }

        Long id = null;
        try {
            JSONObject objId = new JSONObject(corpo);
            id = objId.getLong("id");
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return id;
    }
}
