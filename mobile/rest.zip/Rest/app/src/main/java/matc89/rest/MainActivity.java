package matc89.rest;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ContatoResource contatoResource;
    private List<Contato> contatos;

    private TextView textContatos;
    private EditText editNome;
    private EditText editTelefone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy
                .Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        textContatos = (TextView)findViewById(R.id.listaContatos);
        editNome = (EditText)findViewById(R.id.editNome);
        editTelefone = (EditText)findViewById(R.id.editTelefone);

        contatoResource = new ContatoResource();
        atualizaInterface();
    }

    public void atualizaInterface() {
        try {
            contatos = contatoResource.getContatos();
            String texto = "";
            for (Contato contato : contatos) {
                texto += contato.toString() + "\n";
            }
            textContatos.setText(texto);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void inserirContato(View v) {
        String nome = editNome.getText().toString();
        String telefone = editTelefone.getText().toString();
        Contato contato = new Contato(nome, telefone);
        Long id = null;
        try {
            id = contatoResource.insertContato(contato);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.i("zzz", "Id do contato inserido: " + id);
        Toast.makeText(this, "Contato inserido com id " + id, Toast.LENGTH_SHORT).show();
        atualizaInterface();
    }
}
