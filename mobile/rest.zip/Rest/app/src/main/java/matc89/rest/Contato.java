package matc89.rest;

/**
 * Created by rodrigorgs on 20/09/19.
 */
public class Contato {
    private long id;
    private String nome;
    private String telefone;

    @Override
    public String toString() {
        return "Contato{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", telefone='" + telefone + '\'' +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Contato(String nome, String telefone) {

        this.nome = nome;
        this.telefone = telefone;
    }

    public Contato(long id, String nome, String telefone) {

        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
    }
}
