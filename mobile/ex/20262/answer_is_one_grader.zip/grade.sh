#!/bin/sh

# The runner supplies the question index as $1; this grader applies the same
# rule to every question. BusyBox tr handles the surrounding ASCII whitespace
# accepted by ordinary form submissions.
answer="$(tr -d '[:space:]')"
[ "$answer" = '1' ]
