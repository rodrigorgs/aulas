#!/bin/sh
set -eu

case "${1:-}" in
  0) question="listview01" ;;
  1) question="listview03" ;;
  *)
    echo "Unsupported question index: ${1:-<missing>}. Expected 0 or 1." >&2
    exit 2
    ;;
esac

workdir="$(mktemp -d /tmp/flutter-listview-grader.XXXXXX)"
trap 'rm -rf "$workdir"' EXIT HUP INT TERM

mkdir -p "$workdir/lib" /tmp/flutter-home
cp /opt/grader/pubspec.yaml /opt/grader/pubspec.lock "$workdir/"
cp -R /opt/grader/.dart_tool /opt/grader/lib /opt/grader/test "$workdir/"

# The student's complete Dart answer is supplied on standard input. For
# listview03, the generated Riverpod part remains beside the submitted file.
cat > "$workdir/lib/$question.dart"

cd "$workdir"
HOME=/tmp/flutter-home flutter test \
  --no-pub \
  --reporter expanded \
  "test/${question}_test.dart"
