// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'listview03.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(itens)
const itensProvider = ItensProvider._();

final class ItensProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<String>>,
          List<String>,
          FutureOr<List<String>>
        >
    with $FutureModifier<List<String>>, $FutureProvider<List<String>> {
  const ItensProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'itensProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$itensHash();

  @$internal
  @override
  $FutureProviderElement<List<String>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<String>> create(Ref ref) {
    return itens(ref);
  }
}

String _$itensHash() => r'ec63a9a108d2fcf603fa4a092e8b829cc6fdb165';
