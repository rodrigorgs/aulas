import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_aulas/listview03.dart';

void main() {
  testWidgets('MyApp mostra carregamento e os itens do provider', (tester) async {
    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          itensProvider.overrideWith((Ref ref) async {
            await Future<void>.delayed(const Duration(seconds: 1));
            return ['banana', 'kiwi'];
          }),
        ],
        child: MyApp(),
      ),
    );

    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    expect(find.text('banana'), findsNothing);
    expect(find.text('Item 1'), findsNothing);

    await tester.pump(const Duration(seconds: 1, milliseconds: 500));
    await tester.pumpAndSettle();

    expect(find.byType(CircularProgressIndicator), findsNothing);
    expect(find.byType(ListView), findsOneWidget);
    expect(find.byType(ListTile), findsNWidgets(2));
    expect(find.text('banana'), findsOneWidget);
    expect(find.text('kiwi'), findsOneWidget);
    expect(find.text('Item 1'), findsNothing);
  });

  test('itensProvider carrega os itens esperados', () async {
    final container = ProviderContainer();
    addTearDown(container.dispose);

    await expectLater(
      container.read(itensProvider.future),
      completion(['Item 1', 'Item 2', 'Item 3']),
    );
  });
}
