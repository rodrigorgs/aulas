# Flutter ListView assignment grader

This archive grades the two questions at:

https://rodrigorgs.github.io/aulas/mobile/ex/20262/listview

The ezsubmission runner passes a zero-based question index as the container's
first argument and the student's complete Dart source on standard input.

| Index | Submitted file |
| ---: | --- |
| 0 | `lib/listview01.dart` |
| 1 | `lib/listview03.dart` |

The container runs only the test associated with the selected question. Exit
status zero means the answer passed; a nonzero test result means it failed.

The grader uses Flutter 3.47.5 and Dart 3.13.4. The generated Riverpod part for
`listview03.dart` is included in the archive and does not need to be submitted.
