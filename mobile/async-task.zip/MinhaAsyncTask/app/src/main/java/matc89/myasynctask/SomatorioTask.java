package matc89.myasynctask;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by rodrigorgs on 25/09/19.
 */

public class SomatorioTask extends AsyncTask<Long, Integer, String> {
    private Context context;
    private ProgressDialog dialog;
    private TextView textView;

    public SomatorioTask(Context context, TextView textView) {
        this.context = context;
        this.textView = textView;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog = new ProgressDialog(context);
        dialog.setMax(100);
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.show();
    }

    @Override
    protected String doInBackground(Long... integers) {
        Long numeroIteracoes = integers[0];
        Long valorInicial = integers[1];

        dialog.setMax(numeroIteracoes.intValue() - 1);

        long soma = valorInicial;
        for (long i = 0; i < integers[0]; i++) {
            soma += i;
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Log.d("qwerty", "soma parcial: " + soma);

            publishProgress((int) i);
        }

        return "Somatorio: " + soma;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);

        textView.setText("Progresso: " + values[0]);
        dialog.setProgress(values[0]);
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        dialog.dismiss();
        Toast.makeText(context, s, Toast.LENGTH_SHORT).show();
    }
}
