package matc89.myasynctask;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView)findViewById(R.id.textView);
    }

    public void tarefaDemorada(View v) {
        SomatorioTask task = new SomatorioTask(this, textView);
        // Parâmetros: número de iterações, valor inicial
        task.execute(40L, 1000L);
    }
}
